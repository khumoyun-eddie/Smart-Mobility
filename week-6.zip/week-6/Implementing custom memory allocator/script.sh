# to run allocator_traits
ros2 run demo_nodes_cpp allocator_tutorial

# or to run the example with intra-process pipeline
ros2 run demo_nodes_cpp allocator_tutorial intra